# Fintec Backend Demo

This is a demo backend for FintecMarkets — endpoint to fetch account summary and trades.

## Endpoint
`POST /api/accounts/fetch`

### Request body
```json
{
  "broker": "FSM",
  "server": "FSM-Server",
  "account_number": "1234567",
  "investor_password": "password_here"
}
```

### Response example
```json
{
  "status": "ok",
  "account": { ... },
  "positions": [ ... ],
  "recent_trades": [ ... ]
}
```
